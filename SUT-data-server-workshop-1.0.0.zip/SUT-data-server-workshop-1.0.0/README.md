# SUT Data Server

🎮 Node.js + MongoDB Workshop


## Usage

#### via npm

```
npm install
npm start
```

#### via yarn

```
yarn
yarn start
```
